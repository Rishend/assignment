import React, { useState } from 'react';
import Widget from './Widget';
import AddWidgetForm from './AddWidgetForm';

function Category({ category, onAddWidget, onRemoveWidget, searchTerm }) {
    const [showAddWidgetForm, setShowAddWidgetForm] = useState(false);

    const handleAddWidgetClick = () => {
        setShowAddWidgetForm(true);
    };

    const handleAddWidgetSubmit = (widgetName, widgetText) => {
        onAddWidget(category.id, widgetName, widgetText);
        setShowAddWidgetForm(false);
    };

    const handleRemoveWidget = (widgetId) => {
        onRemoveWidget(category.id, widgetId);
    };

    return (
        <div>
            <h2>{category.name}</h2>
            <ul>
                {category.widgets.filter(widget => {
                    if (searchTerm) {
                        return widget.name.toLowerCase().includes(searchTerm.toLowerCase());
                    }
                    return true;
                }).map(widget => (
                    <Widget key={widget.id} widget={widget} onRemoveWidget={handleRemoveWidget} />
                ))}
            </ul>
            {showAddWidgetForm ? (
                <AddWidgetForm onSubmit={handleAddWidgetSubmit} />
            ) : (
                <button onClick={handleAddWidgetClick}> Add Widget</button>
            )}

            
        </div>
    );
}

export default Category;