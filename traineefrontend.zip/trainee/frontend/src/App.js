import React from "react";
import Navbar from "./Navbar";
import Category from "./Category";
import CategoryList from "./CategoryList";
import Widget from "./Widget"; 

function App() {
  return ( 
    <div>
      <Navbar />
      <Category />
      <CategoryList/>
      <Widget/>
    </div>
  );
}

export default App;