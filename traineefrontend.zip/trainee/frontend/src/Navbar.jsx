import React from 'react'
import {Link} from 'react-router-dom';
import { NavLink } from 'react-router-dom';
const Navbar = () => {
  return (
   

    <nav>
      <ul>
        <li>
          <NavLink className="nav-link" to="/AddWidgetForm">
            AddWidgetForm
          </NavLink>
        </li>
        <li>
          <NavLink className="nav-link" to="/Category">
            Category
          </NavLink>
        </li>
      </ul>
    </nav>
  );
};


export default Navbar
