import React, { useState } from 'react';



const AddWidget = () => {
  
  return <div>Add Widget</div>;
};