import React, { useState, memo } from 'react';

const Dashboard = () => {
  const [widgets, setWidgets] = useState([
    { id: 1, type: 'Widget1' },
    { id: 2, type: 'Widget2' },
  ]);

  const handleAddWidget = React.useCallback((widgetType) => {
    const newWidget = { id: widgets.length + 1, type: widgetType };
    setWidgets((prevWidgets) => [...prevWidgets, newWidget]);
  }, [widgets]);

  return (
    <div className="dashboard">
      {widgets.map((widget) => (
        <Widget key={widget.id} type={widget.type} />
      ))}
      <button onClick={() => handleAddWidget('Widget3')}>Add Widget 3</button>
    </div>
  );
};

const Widget = memo(({ type }) => {
  switch (type) {
    case 'Widget1':
      return <div>Widget 1 content</div>;
    case 'Widget2':
      return <div>Widget 2 content</div>;
    case 'Widget3':
      return <div>Widget 3 content</div>;
    default:
      return null;
  }
});

export default Dashboard;