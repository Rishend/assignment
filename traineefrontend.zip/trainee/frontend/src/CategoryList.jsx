import React from 'react';
import Category from './Category';

const CategoryList = ({ categories, onAddWidget, onRemoveWidget, searchTerm }) => {
  return (
    <div>
      {categories.map(category => (
        <Category
          key={category.id}
          category={category}
          onAddWidget={onAddWidget}
          onRemoveWidget={onRemoveWidget}
          searchTerm={searchTerm}
        />
      ))}
    </div>
  );
};

export default CategoryList;